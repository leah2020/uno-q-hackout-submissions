"""Bar Master: tilt the console to pour layered drinks and hit each fill line."""
import json
import time
from pathlib import Path

from arduino.app_utils import App, Bridge

from controls import C, HOLD_TO_POUR, LEARN_DEG, Controls, Tilt, parse_inputs
from draw import Batch
from game import POURING, Game
from ui import Ui

FRAME_SECONDS = 0.04
CALL_TIMEOUT = 5.0  # a full-screen repaint can keep the sketch busy for a second or two
BEST_FILE = Path(__file__).resolve().parent.parent / "data" / "highscore.json"


def load_best():
    """Best score per mode, e.g. {"NORMAL": 1450}."""
    try:
        best = json.loads(BEST_FILE.read_text())["best"]
        return {str(mode): max(0, int(score)) for mode, score in best.items()}
    except (OSError, ValueError, KeyError, TypeError, AttributeError):
        return {}


def save_best(best):
    try:
        BEST_FILE.parent.mkdir(parents=True, exist_ok=True)
        BEST_FILE.write_text(json.dumps({"best": best}))
    except OSError as error:
        print(f"Could not save the best score: {error}")


class Runner:
    """One frame: read controls, update the rules, send only the changed pixels."""

    def __init__(self, call):
        self.call = call
        self.game = Game(best=load_best())
        self.saved_best = dict(self.game.best)
        self.ui = Ui()
        self.controls = Controls()
        self.tilt = Tilt()
        self.inputs = None
        self.epoch = None
        self.last = time.monotonic()

    def send(self, batch):
        reply = None
        for payload in batch.chunks():
            reply = self.call("bar_draw", payload)
        data = parse_inputs(reply)
        if data["epoch"] != self.epoch:
            # The sketch repainted the screen by itself (start-up or a frame timeout).
            self.epoch = data["epoch"]
            self.ui.invalidate()
        self.inputs = data

    def step(self):
        now = time.monotonic()
        dt = min(now - self.last, 0.25)
        self.last = now
        if self.inputs is None:
            self.send(Batch())
        self.controls.update(self.inputs)
        self.tilt.update(self.inputs, self.game.capturing_neutral)
        pouring = self.controls.held & C or not HOLD_TO_POUR
        if (self.tilt.direction is None and self.game.state == POURING and pouring
                and self.tilt.angle() >= LEARN_DEG):
            self.tilt.learn()  # the first real pour sets which side pours
        angle = self.tilt.pour_angle()
        self.game.update(dt, self.controls, angle)
        if self.game.best != self.saved_best:
            save_best(self.game.best)
            self.saved_best = dict(self.game.best)
        self.send(self.ui.render(self.game, self.controls, angle, now))

    def recover(self):
        self.inputs = None
        self.ui.invalidate()
        self.last = time.monotonic()


runner = Runner(lambda method, *args: Bridge.call(method, *args, timeout=CALL_TIMEOUT))


def loop():
    started = time.monotonic()
    try:
        runner.step()
    except Exception as error:
        # Without fresh frames the sketch shows its waiting screen after 1.5 seconds.
        print(f"Bar Master connection/input error: {error}")
        runner.recover()
        time.sleep(1)
        return
    time.sleep(max(0.0, FRAME_SECONDS - (time.monotonic() - started)))


print("Bar Master: pick a mode with the stick, press C to start. Hold C and tilt left to pour.")
App.run(user_loop=loop)
