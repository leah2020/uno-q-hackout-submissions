"""Pack drawing commands into small binary batches for the sketch's bar_draw RPC.

The byte layout must match sketch/draw_protocol.h: little-endian, one opcode byte
followed by fixed fields; TEXT also carries its ASCII bytes.
"""
import struct

SCREEN_W, SCREEN_H = 480, 320
# A whole RPC request must fit the sketch's 256-byte receive buffer.
MAX_PAYLOAD = 160
MAX_TEXT = 40

CLEAR, FILL_RECT, DRAW_RECT, FILL_CIRCLE, DRAW_CIRCLE, LINE, FILL_TRIANGLE, TEXT, LEDS = range(1, 10)

# RGB565. The TFT fills a color fastest when its high and low bytes match, so the
# large areas (background, panels, drinks) use such colors.
BLACK = 0x0000
WHITE = 0xFFFF
GREY = 0x8410
PANEL = 0x2929
PINK = 0xF8F8
BLUE = 0x1A1A
LIME = 0x8787
YELLOW = 0xFFE0
GREEN = 0x07E0
RED = 0xF800
AMBER = 0xFD80


def text_width(text, size):
    return len(text) * 6 * size


def centered(text, size, left=0, width=SCREEN_W):
    return left + (width - text_width(text, size)) // 2


def _coord(value):
    return max(-1000, min(2000, int(value)))


class Batch:
    """Collects drawing commands for one frame."""

    def __init__(self):
        self.ops = []

    def __len__(self):
        return len(self.ops)

    def _add(self, fmt, *values):
        self.ops.append(struct.pack("<" + fmt, *values))

    def clear(self, color):
        self._add("BH", CLEAR, color)

    def fill_rect(self, x, y, w, h, color):
        if w > 0 and h > 0:
            self._add("BhhhhH", FILL_RECT, _coord(x), _coord(y), _coord(w), _coord(h), color)

    def draw_rect(self, x, y, w, h, color, thickness=1):
        for inset in range(thickness):
            self._add("BhhhhH", DRAW_RECT, _coord(x + inset), _coord(y + inset),
                      _coord(w - 2 * inset), _coord(h - 2 * inset), color)

    def fill_circle(self, x, y, r, color):
        self._add("BhhhH", FILL_CIRCLE, _coord(x), _coord(y), _coord(r), color)

    def draw_circle(self, x, y, r, color):
        self._add("BhhhH", DRAW_CIRCLE, _coord(x), _coord(y), _coord(r), color)

    def line(self, x0, y0, x1, y1, color):
        self._add("BhhhhH", LINE, _coord(x0), _coord(y0), _coord(x1), _coord(y1), color)

    def fill_triangle(self, x0, y0, x1, y1, x2, y2, color):
        self._add("BhhhhhhH", FILL_TRIANGLE, _coord(x0), _coord(y0), _coord(x1), _coord(y1),
                  _coord(x2), _coord(y2), color)

    def text(self, x, y, size, color, text, bg=None):
        """Draw ASCII text; without bg only the letter pixels are drawn (faster)."""
        data = text.encode("ascii", "replace")[:MAX_TEXT]
        bg = color if bg is None else bg
        self.ops.append(struct.pack("<BhhBHHB", TEXT, _coord(x), _coord(y), size, color, bg,
                                    len(data)) + data)

    def leds(self, a, b, c):
        self._add("BB", LEDS, (1 if a else 0) | (2 if b else 0) | (4 if c else 0))

    def chunks(self):
        """Split the frame into payloads small enough for one RPC each."""
        payloads, current = [], b""
        for op in self.ops:
            if current and len(current) + len(op) > MAX_PAYLOAD:
                payloads.append(current)
                current = b""
            current += op
        if current or not payloads:
            payloads.append(current)
        return payloads
