"""Bar Master rules: modes, guests, pouring, scoring and the shift state machine.

Nothing here talks to the hardware, so the rules can be tested on a computer.
"""
import random

from controls import (A, B, C, HOLD_TO_POUR, STEP_REARM, STICK, POUR_FULL_DEG, POUR_START_DEG,
                      SPLASH_DEG, SPLASH_REARM_DEG, missing_names)

PINK, BLUE, LIME = "PINK", "BLUE", "LIME"
BOTTLES = (PINK, BLUE, LIME)

# Recipes by number of layers: (name, ((bottle, percent of the glass), ...)).
RECIPES = {
    1: (("PINK SHOT", ((PINK, 50),)), ("BLUE LAGOON", ((BLUE, 60),)),
        ("LIME SODA", ((LIME, 40),)), ("BERRY CUP", ((PINK, 70),))),
    2: (("SUNRISE", ((PINK, 40), (LIME, 30))), ("OCEAN", ((BLUE, 40), (LIME, 20))),
        ("BERRY SKY", ((PINK, 30), (BLUE, 40))), ("MINT KISS", ((LIME, 30), (PINK, 30)))),
    3: (("SUNSET", ((PINK, 30), (BLUE, 30), (LIME, 20))),
        ("RAINBOW", ((LIME, 20), (PINK, 30), (BLUE, 30))),
        ("NEON", ((BLUE, 20), (LIME, 30), (PINK, 30))),
        ("TRICOLOR", ((PINK, 20), (LIME, 20), (BLUE, 40)))),
}
TUTORIAL_RECIPE = ("FIRST DRINK", ((BLUE, 50),))
# Guests per mode: (layers, seconds, blind). Each shift gets harder as it goes.
TUTORIAL, EASY, NORMAL, HARD = "TUTORIAL", "EASY", "NORMAL", "HARD"
MODES = (TUTORIAL, EASY, NORMAL, HARD)
LEVELS = {
    TUTORIAL: ((1, 0, False),),
    EASY: ((1, 35, False), (1, 35, False), (2, 30, False), (2, 30, False)),
    NORMAL: ((1, 25, False), (1, 25, False), (2, 22, False), (2, 22, False),
             (3, 20, False), (3, 20, False)),
    HARD: ((1, 18, False), (2, 18, False), (2, 16, False), (3, 16, False),
           (3, 15, False), (3, 15, True), (3, 14, True), (3, 14, True)),
}
MODE_INFO = {
    TUTORIAL: "LEARN TO POUR, NO TIMER",
    EASY: "4 GUESTS, LOTS OF TIME",
    NORMAL: "6 GUESTS, UP TO 3 LAYERS",
    HARD: "8 GUESTS, FAST + BLIND",
}
LIVES = 3
INTRO_SECONDS = 2.0
NEUTRAL_CAPTURE_SECONDS = 1.2  # the end of the intro, while the player holds still
RESULT_SECONDS = 1.6
BLIND_VISIBLE_SECONDS = 3.0
MAX_POUR_PER_SECOND = 20.0  # percent of the glass at full tilt
SPLASH_EXTRA = (3.0, 8.0)
SPLASH_PENALTY = 50
TIME_BONUS_PER_SECOND = 5
TOLERANCE = 3.0
DRIP = 1.0  # layers thinner than this are ignored when scoring
RATINGS = ((TOLERANCE, "PERFECT", 300), (8.0, "GOOD", 200), (15.0, "OK", 100))
MAX_COMBO = 3  # back-to-back PERFECTs multiply the base points up to x3
STAR_SCORES_PER_GUEST = (210, 120)  # 3 and 2 stars; any points earn 1

TITLE, INTRO, POURING, SERVED, RESULT = "title", "intro", "pouring", "served", "result"


def merged(layers, minimum=0.0):
    """Join neighbouring layers of the same drink, skipping layers below minimum."""
    out = []
    for color, amount in layers:
        if amount < minimum:
            continue
        if out and out[-1][0] == color:
            out[-1][1] += amount
        else:
            out.append([color, amount])
    return out


def rate_glass(glass, recipe):
    """Return (rating, points, worst layer error in percent)."""
    poured = merged(glass, DRIP)
    worst = 0.0
    for i in range(max(len(poured), len(recipe))):
        have = poured[i] if i < len(poured) else None
        want = recipe[i] if i < len(recipe) else None
        if have and want and have[0] == want[0]:
            error = abs(have[1] - want[1])
        else:
            error = max(have[1] if have else 0.0, want[1] if want else 0.0)
        worst = max(worst, error)
    for limit, name, points in RATINGS:
        if worst <= limit:
            return name, points, worst
    return "MISS", 0, worst


def pour_speed(tilt_deg):
    return max(0.0, min(1.0, (tilt_deg - POUR_START_DEG) / (POUR_FULL_DEG - POUR_START_DEG)))


class Game:
    def __init__(self, best=None, rng=None):
        self.rng = rng or random.Random()
        self.best = dict(best or {})
        # First-timers start on the tutorial; returning players on NORMAL.
        self.mode = NORMAL if self.best else TUTORIAL
        self.state = TITLE
        self.paused = False
        self.pause_reason = ""
        self.new_best = False
        self.selected = 0
        self._reset_shift()

    def _reset_shift(self):
        self.levels = LEVELS[self.mode]
        self.guest = 0
        self.score = 0
        self.lives = LIVES
        self.streak = 0
        self.counts = {"PERFECT": 0, "GOOD": 0, "OK": 0, "MISS": 0}
        self.recipe_name = ""
        self.recipe = ()
        self.glass = []
        self.time_limit = 1.0
        self.time_left = 0.0
        self.blind = False
        self.phase_time = 0.0
        self.pour_time = 0.0
        self.speed = 0.0
        self.trigger = False  # C held (always True without HOLD_TO_POUR)
        self.splash_time = 0.0
        self._splash_armed = True
        self.result_text = ""
        self.result_points = 0
        self.multiplier = 1
        self._last_recipe = None

    # --- facts the screen shows -------------------------------------------------

    @property
    def guests(self):
        return len(self.levels)

    @property
    def tutorial(self):
        return self.mode == TUTORIAL

    @property
    def best_score(self):
        return self.best.get(self.mode, 0)

    @property
    def timed(self):
        return not self.tutorial

    @property
    def capturing_neutral(self):
        return (self.state == INTRO and not self.paused
                and self.phase_time >= INTRO_SECONDS - NEUTRAL_CAPTURE_SECONDS)

    def total(self):
        return sum(amount for _, amount in self.glass)

    def layers(self):
        return merged(self.glass)

    def current_layer(self):
        return max(0, min(len(self.recipe) - 1, len(self.layers()) - 1))

    def target(self, index):
        return sum(amount for _, amount in self.recipe[:index + 1])

    def wrong_bottle(self):
        layers = self.layers()
        if not layers:
            return False
        index = len(layers) - 1
        return index >= len(self.recipe) or layers[index][0] != self.recipe[index][0]

    def line_visible(self):
        return not self.blind or self.state == INTRO or self.pour_time < BLIND_VISIBLE_SECONDS

    def left_to_pour(self):
        return self.target(self.current_layer()) - self.total()

    def in_zone(self):
        return (self.state == POURING and self.line_visible() and bool(self.glass)
                and not self.wrong_bottle() and abs(self.left_to_pour()) <= TOLERANCE)

    def row_marks(self):
        """OK / ~ / X for finished layers, blank for the rest."""
        layers, current = self.layers(), self.current_layer()
        marks = []
        for i, (color, amount) in enumerate(self.recipe):
            if i >= current or i >= len(layers) or layers[i][0] != color:
                marks.append("X" if i < current else "")
                continue
            error = abs(layers[i][1] - amount)
            marks.append("OK" if error <= TOLERANCE else ("~" if error <= 8 else "X"))
        return tuple(marks)

    def tutorial_step(self):
        """(step key, long instruction, short hint) for the guided first drink."""
        if self.state == INTRO:
            return ("still", "HOLD THE CONSOLE STILL, LIKE THIS", "HOLD STILL")
        want = BOTTLES.index(self.recipe[0][0])
        if self.wrong_bottle():
            return ("dump", "WRONG BOTTLE! PRESS B, THEN PICK BLUE", "PRESS B")
        if self.glass and self.left_to_pour() < -TOLERANCE:
            return ("dump", "TOO MUCH! PRESS B TO EMPTY THE GLASS", "PRESS B")
        if not self.glass and self.selected != want:
            arrow = "RIGHT" if self.selected < want else "LEFT"
            return ("pick", f"1/5 PUSH THE STICK {arrow} TO PICK BLUE", "PICK BLUE")
        if self.in_zone():
            if self.speed > 0:
                return ("release", "4/5 LET GO OF C NOW!", "LET GO NOW!")
            return ("serve", "5/5 PERFECT! PRESS A TO SERVE IT", "PRESS A")
        if not self.trigger:
            return ("hold", "2/5 PRESS AND HOLD THE C BUTTON", "HOLD C")
        if self.speed == 0 and self.total() < 3:
            return ("tilt", "3/5 KEEP HOLDING C AND TILT LEFT", "TILT LEFT")
        if self.left_to_pour() > 8:
            return ("fill", "4/5 FILL UP TO THE YELLOW LINE...", "KEEP GOING")
        return ("fill", "4/5 SLOW DOWN, LET GO AT THE LINE", "GET READY")

    def status(self):
        """Short hint and its color name for the panel under the pour gauge."""
        if self.state != POURING:
            return "", "white"
        if self.tutorial:
            key, _, hint = self.tutorial_step()
            color = {"dump": "red", "release": "red", "serve": "green"}.get(key, "amber")
            return hint, color
        if self.splash_time > 0:
            return "SPLASH! -50", "red"
        if not self.line_visible():
            return "BLIND POUR!", "amber"
        if not self.glass:
            return ("HOLD C+TILT" if HOLD_TO_POUR else "TILT TO POUR"), "white"
        if self.wrong_bottle():
            return "WRONG BOTTLE", "red"
        left = self.left_to_pour()
        if left > 8:
            return "KEEP GOING", "white"
        if left > TOLERANCE:
            return "ALMOST...", "amber"
        if left >= -TOLERANCE:
            if self.speed > 0:
                return ("LET GO OF C" if HOLD_TO_POUR else "STOP! LEVEL"), "red"
            last = self.current_layer() == len(self.recipe) - 1
            return ("SERVE! (A)" if last else "NEXT BOTTLE"), "green"
        return "TOO MUCH!", "red"

    def stars(self):
        three, two = (points * self.guests for points in STAR_SCORES_PER_GUEST)
        return 3 if self.score >= three else 2 if self.score >= two else 1 if self.score else 0

    # --- rules ------------------------------------------------------------------

    def update(self, dt, controls, tilt_deg):
        pressed = controls.pressed
        missing = controls.missing()
        if self.state == TITLE:
            if controls.step:
                index = MODES.index(self.mode) + controls.step
                self.mode = MODES[max(0, min(len(MODES) - 1, index))]
            elif pressed & C and not missing:
                self._start_shift()
            return
        if self.state == RESULT:
            if pressed & C and not missing:
                if self.tutorial:
                    self.mode = EASY  # training done: straight into a real shift
                self._start_shift()
            elif pressed & B:
                self._to_title()
            return
        if (missing or self.paused) and pressed & B:
            self._to_title()  # quit the shift from the pause box
            return
        if missing:
            # A guest is waiting, so stop the clock until every control is back.
            self.paused = True
            self.pause_reason = "NO " + "+".join(missing_names(missing))
            return
        if self.paused:
            self.pause_reason = ""
            if pressed & STICK:
                self.paused = False
            return
        # Ignore presses while the stick is pushed sideways to pick a bottle.
        if pressed & STICK and self.state != SERVED and abs(controls.x) < STEP_REARM:
            self.paused = True
            return

        self.phase_time += dt
        if self.state == SERVED:
            if self.phase_time >= RESULT_SECONDS:
                self._next_guest()
            return
        if controls.step:
            self.selected = max(0, min(len(BOTTLES) - 1, self.selected + controls.step))
        if self.state == INTRO:
            if self.phase_time >= INTRO_SECONDS:
                self.state = POURING
                self.phase_time = 0.0
            return

        if self.timed:
            self.time_left = max(0.0, self.time_left - dt)
        self.pour_time += dt
        self.splash_time = max(0.0, self.splash_time - dt)
        self.trigger = bool(controls.held & C) or not HOLD_TO_POUR
        self.speed = pour_speed(tilt_deg) if self.trigger else 0.0
        if self.speed > 0:
            self._pour(MAX_POUR_PER_SECOND * self.speed * dt)
        if self.trigger and tilt_deg >= SPLASH_DEG and self._splash_armed:
            self._splash_armed = False
            self.splash_time = 1.0
            self.score = max(0, self.score - SPLASH_PENALTY)
            self._pour(self.rng.uniform(*SPLASH_EXTRA))
        elif tilt_deg < SPLASH_REARM_DEG:
            self._splash_armed = True

        if self.total() > 100.0:
            self._finish("OVERFLOW!", 0, failed=True)
        elif pressed & A and self.total() >= DRIP:
            self._serve()
        elif pressed & B:
            self.glass = []
        elif self.timed and self.time_left <= 0:
            self._finish("TIME UP!", 0, failed=True)

    def _serve(self):
        rating, points, _ = rate_glass(self.glass, self.recipe)
        self.counts[rating] += 1
        if rating == "MISS":
            self._finish("MISS", 0, failed=True)
            return
        self.streak = self.streak + 1 if rating == "PERFECT" else 0
        self.multiplier = max(1, min(MAX_COMBO, self.streak))
        points = points * self.multiplier + int(self.time_left) * TIME_BONUS_PER_SECOND * self.timed
        self._finish(rating + "!", points, failed=False)

    def _pour(self, amount):
        color = BOTTLES[self.selected]
        if self.glass and self.glass[-1][0] == color:
            self.glass[-1][1] += amount
        else:
            self.glass.append([color, amount])

    def _start_shift(self):
        self._reset_shift()
        self.new_best = False
        self.paused = False
        if self.tutorial:
            self.selected = 0  # the lesson starts by moving to the blue bottle
        self._begin_guest(0)

    def _to_title(self):
        self.state = TITLE
        self.paused = False
        self.pause_reason = ""
        self.trigger = False
        self.speed = 0.0

    def _begin_guest(self, index):
        layers, seconds, blind = self.levels[index]
        if self.tutorial:
            self.recipe_name, self.recipe = TUTORIAL_RECIPE
        else:
            choices = [r for r in RECIPES[layers] if r[0] != self._last_recipe]
            self.recipe_name, self.recipe = self.rng.choice(choices)
        self._last_recipe = self.recipe_name
        self.guest = index
        self.glass = []
        self.time_limit = float(seconds or 1)
        self.time_left = self.time_limit
        self.blind = blind
        self.state = INTRO
        self.phase_time = 0.0
        self.pour_time = 0.0
        self.speed = 0.0
        self.splash_time = 0.0
        self._splash_armed = True

    def _finish(self, text, points, failed):
        if failed:
            self.streak = 0
            self.multiplier = 1
            if self.tutorial:
                text = "TRY AGAIN"  # practice never costs a life
            else:
                self.lives -= 1
                if text != "MISS":
                    self.counts["MISS"] += 1
        self.score += points
        self.result_text = text
        self.result_points = points
        self.speed = 0.0
        self.trigger = False
        self.state = SERVED
        self.phase_time = 0.0

    def _next_guest(self):
        if self.tutorial and self.result_text == "TRY AGAIN":
            self.glass = []
            self.state = POURING
            self.phase_time = 0.0
        elif self.lives <= 0 or self.guest + 1 >= len(self.levels):
            self.state = RESULT
            self.new_best = not self.tutorial and self.score > self.best_score
            if self.new_best:
                self.best[self.mode] = self.score
        else:
            self._begin_guest(self.guest + 1)
