"""Draw Bar Master on the 480x320 TFT, sending only what changed since the last frame.

Every widget remembers what it last drew in self.cache. Full repaints happen only
when the screen changes, because filling the whole TFT takes about a second.
"""
import math

import game as g
from controls import HOLD_TO_POUR, POUR_START_DEG, SPLASH_DEG, missing_names
from draw import (AMBER, BLACK, BLUE, GREEN, GREY, LIME, PANEL, PINK, RED, WHITE, YELLOW,
                  Batch, centered, text_width)

DRINK = {g.PINK: PINK, g.BLUE: BLUE, g.LIME: LIME}
HINT = {"white": WHITE, "green": GREEN, "amber": AMBER, "red": RED}
BOTTLE_X = (346, 394, 442)
LIVES_X = (228, 248, 268)
ROW_Y, ROW_GAP = 104, 40

# The glass is a 2-pixel outline around an interior that fills from the bottom.
GLASS_RECT = (213, 69, 82, 224)
IN_X, IN_W = 215, 78
IN_TOP, IN_BOTTOM = 71, 291  # interior rows [IN_TOP, IN_BOTTOM)
IN_H = IN_BOTTOM - IN_TOP
GLASS_AREA = (180, 62, 134, 234)  # everything the glass widget owns, banner included
BANNER = (182, 128, 130, 76)

TIMER_X, TIMER_Y, TIMER_W, TIMER_H = 9, 41, 462, 6
GAUGE_Y, GAUGE_H = 212, 18
GAUGE_ZONES = ((324, 352, GREY), (352, 436, GREEN), (436, 464, RED))  # x ranges [start, end)
NEEDLE_TOP, NEEDLE_H, NEEDLE_W = 206, 30, 4
GAUGE_LABEL_Y = 238  # just below the needle
STATUS = (324, 250, 148, 16)
if HOLD_TO_POUR:
    SUBTITLE = "HOLD C, TILT LEFT TO POUR!"
    POUR_KEY = "HOLD C+TILT"
    CONTROL_HINT = "<>BOTTLE  C+TILT POUR  A SERVE  B DUMP"
    POUR_TIPS = ("HOLD C + TILT LEFT", "MORE TILT = FASTER", "LET GO OF C = STOP")
else:
    SUBTITLE = "TILT LEFT TO POUR. HIT THE LINE!"
    POUR_KEY = "TILT LEFT"
    CONTROL_HINT = "<>BOTTLE  TILT POUR  A SERVE  B DUMP"
    POUR_TIPS = ("TILT LEFT TO POUR", "MORE TILT = FASTER", "LEVEL IT = STOP")
TUTORIAL_TIPS = ("PRACTICE: NO TIMER", "FOLLOW THE YELLOW", "STEPS AT THE BOTTOM")
_UNSET = object()


def level_y(percent):
    return IN_BOTTOM - round(max(0.0, min(100.0, percent)) / 100.0 * IN_H)


def row_colors(layers):
    """Color of every interior row, top to bottom."""
    rows = [BLACK] * IN_H
    level = 0.0
    for color, amount in layers:
        top, bottom = level_y(level + amount), level_y(level)
        for y in range(top, bottom):
            rows[y - IN_TOP] = DRINK[color]
        level += amount
    return rows


def paint_rows(batch, rows, indexes):
    """Fill the given interior rows with their colors, one rectangle per run."""
    start = previous = None
    for index in sorted(indexes) + [None]:
        if start is not None and (index is None or index != previous + 1
                                  or rows[index] != rows[start]):
            batch.fill_rect(IN_X, IN_TOP + start, IN_W, previous - start + 1, rows[start])
            start = None
        if index is not None and start is None:
            start = index
        previous = index


def needle_x(angle):
    if angle <= POUR_START_DEG:
        x = 324 + angle / POUR_START_DEG * 28
    elif angle <= SPLASH_DEG:
        x = 352 + (angle - POUR_START_DEG) / (SPLASH_DEG - POUR_START_DEG) * 84
    else:
        x = 436 + min(1.0, (angle - SPLASH_DEG) / 15.0) * 28
    return max(326, min(462, int(x) // 2 * 2))


def star(batch, cx, cy, r, color, filled):
    points = []
    for i in range(10):
        radius = r if i % 2 == 0 else r * 0.45
        angle = -math.pi / 2 + i * math.pi / 5
        points.append((round(cx + radius * math.cos(angle)), round(cy + radius * math.sin(angle))))
    for i in range(10):
        (x0, y0), (x1, y1) = points[i], points[(i + 1) % 10]
        if filled:
            # A star is visible from its center, so a fan of triangles covers it exactly.
            batch.fill_triangle(cx, cy, x0, y0, x1, y1, color)
        else:
            batch.line(x0, y0, x1, y1, color)


def bottle(batch, cx, color, name):
    batch.fill_rect(cx - 7, 72, 14, 6, GREY)
    batch.fill_rect(cx - 6, 78, 12, 18, color)
    batch.fill_rect(cx - 16, 96, 32, 56, color)
    batch.fill_rect(cx - 10, 110, 20, 22, WHITE)
    batch.text(cx - 6, 117, 1, BLACK, name[:2])


class Ui:
    def __init__(self):
        self.invalidate()

    def invalidate(self):
        """Forget the TFT contents so the next frame repaints everything."""
        self.screen = None
        self.cache = {}

    def render(self, game, controls, tilt_deg, now):
        batch = Batch()
        if game.state == g.TITLE:
            self._title(batch, game, controls, now)
        elif game.state == g.RESULT:
            self._result(batch, game, now)
        else:
            self._play(batch, game, tilt_deg)
        return batch

    def _changed(self, key, value):
        if self.cache.get(key, _UNSET) == value:
            return False
        self.cache[key] = value
        return True

    def _enter(self, batch, screen):
        if self.screen == screen:
            return False
        batch.clear(BLACK)
        self.screen = screen
        self.cache = {}
        return True

    def _leds(self, batch, a, b, c):
        if self._changed("leds", (bool(a), bool(b), bool(c))):
            batch.leds(a, b, c)

    # --- title ----------------------------------------------------------------

    def _title(self, b, game, controls, now):
        if self._enter(b, "title"):
            b.text(centered("BAR MASTER", 5), 22, 5, PINK, "BAR MASTER")
            b.text(centered(SUBTITLE, 2), 72, 2, WHITE, SUBTITLE)
            b.draw_rect(60, 118, 64, 140, WHITE, 2)
            bottom = 256
            for color, amount in ((PINK, 30), (BLUE, 30), (LIME, 20)):
                height = round(136 * amount / 100)
                b.fill_rect(62, bottom - height, 60, height, color)
                bottom -= height
            b.draw_rect(152, 110, 312, 132, GREY)
            rows = ((POUR_KEY, "POUR (LEFT)"), ("STICK <>", "PICK BOTTLE"), ("A", "SERVE DRINK"),
                    ("B", "DUMP GLASS"), ("STICK PRESS", "PAUSE"))
            for i, (key, action) in enumerate(rows):
                b.text(164, 120 + i * 24, 2, YELLOW, key)
                b.text(316, 120 + i * 24, 2, WHITE, action)
        missing = controls.missing()
        if self._changed("mode", game.mode):
            # The stick picks the mode on this screen.
            b.fill_rect(0, 248, 480, 16, BLACK)
            number = g.MODES.index(game.mode) + 1
            label = f"MODE {number}/{len(g.MODES)}  < {game.mode} >"
            b.text(centered(label, 2), 248, 2, YELLOW, label)
        if self._changed("notice", (missing, game.mode, game.best_score)):
            b.fill_rect(0, 267, 480, 9, BLACK)
            if missing:
                notice = "NO " + "+".join(missing_names(missing))
                b.text(centered(notice, 1), 267, 1, RED, notice)
            else:
                hint, info = "STICK <> CHANGES MODE:", g.MODE_INFO[game.mode]
                if not game.tutorial:
                    info += f"  BEST {game.best_score}"
                x = centered(hint + " " + info, 1)
                b.text(x, 267, 1, WHITE, hint)
                b.text(x + text_width(hint + " ", 1), 267, 1, GREY, info)
        if self._changed("start", bool(missing)):
            b.fill_rect(0, 278, 480, 28, BLACK)
            prompt, color = ("CHECK MODULES", RED) if missing else ("PRESS C TO START", GREEN)
            b.text(centered(prompt, 3), 280, 3, color, prompt)
            self.cache.pop("marker", None)
        blink = int(now * 2) % 2 == 0
        marker_x = centered("PRESS C TO START", 3) - 24
        if not missing and self._changed("marker", blink):
            if blink:
                b.text(marker_x, 280, 3, GREEN, ">")
            else:
                b.fill_rect(marker_x, 280, 18, 24, BLACK)
        self._leds(b, False, False, blink)

    # --- result ---------------------------------------------------------------

    def _result(self, b, game, now):
        if game.tutorial:
            if self._enter(b, "result"):
                b.text(centered("TRAINING DONE", 4), 40, 4, GREEN, "TRAINING DONE")
                b.text(centered("YOU CAN POUR!", 3), 100, 3, WHITE, "YOU CAN POUR!")
                for i, line in enumerate(("REMEMBER: HOLD C + TILT LEFT", "LET GO OF C AT THE LINE",
                                          "A = SERVE    B = DUMP")):
                    b.text(centered(line, 2), 160 + i * 26, 2, YELLOW, line)
                again = "C: PLAY EASY   B: MENU"
                b.text(centered(again, 2), 290, 2, AMBER, again)
            self._leds(b, False, True, int(now * 2) % 2 == 0)
            return
        if self._enter(b, "result"):
            title = f"{game.mode} SHIFT OVER"
            b.text(centered(title, 3), 30, 3, WHITE, title)
            b.text(centered("SCORE", 2), 80, 2, GREY, "SCORE")
            score = str(game.score)
            b.text(centered(score, 5), 104, 5, YELLOW, score)
            earned = game.stars()
            for i in range(3):
                star(b, 190 + i * 50, 182, 20, YELLOW if i < earned else GREY, i < earned)
            if game.new_best:
                b.text(centered("NEW BEST!", 3), 220, 3, GREEN, "NEW BEST!")
            elif game.lives <= 0:
                b.text(centered("OUT OF LIVES", 3), 220, 3, RED, "OUT OF LIVES")
            c = game.counts
            stats = f"PERFECT {c['PERFECT']}  GOOD {c['GOOD']}  OK {c['OK']}  MISS {c['MISS']}"
            b.text(centered(stats, 2), 256, 2, WHITE, stats)
            again = "C: PLAY AGAIN   B: MENU"
            b.text(centered(again, 2), 290, 2, AMBER, again)
        self._leds(b, False, True, int(now * 2) % 2 == 0)

    # --- playing --------------------------------------------------------------

    def _play(self, b, game, tilt_deg):
        if self.screen == "play" and self.cache.get("pause") is not None and not game.paused:
            self.screen = None  # the pause box covered the middle; repaint everything
        if self._enter(b, "play"):
            self._play_frame(b)
        if game.paused:
            if self._changed("pause", game.pause_reason):
                self._pause_box(b, game.pause_reason)
            self._leds(b, False, False, False)
            return
        self._top_bar(b, game)
        self._timer(b, game)
        self._card(b, game)
        self._bottles(b, game)
        self._glass(b, game)
        # A grey needle means nothing is pouring, whatever the tilt.
        self._needle(b, tilt_deg, game.state == g.POURING and game.trigger)
        text, color = game.status()
        if self._changed("status", (text, color)):
            b.fill_rect(*STATUS, BLACK)
            b.text(STATUS[0], STATUS[1], 2, HINT[color], text)
        self._hint_bar(b, game)
        pouring = game.state == g.POURING
        if game.tutorial and pouring:
            # Light the button the lesson asks for.
            step = game.tutorial_step()[0]
            self._leds(b, step == "serve", step == "dump", step in ("hold", "tilt", "fill"))
        else:
            self._leds(b, game.in_zone(), pouring and game.glass,
                       pouring and game.trigger and HOLD_TO_POUR)

    def _hint_bar(self, b, game):
        if not game.tutorial:
            text, color = CONTROL_HINT, WHITE
        elif game.state == g.SERVED:
            text = ("NO WORRIES - EMPTY GLASS, TRY AGAIN" if game.result_text == "TRY AGAIN"
                    else "WELL DONE! FIRST DRINK SERVED!")
            color = GREEN
        else:
            text, color = game.tutorial_step()[1], YELLOW
        if self._changed("hint_bar", text):
            b.fill_rect(0, 296, 480, 24, PANEL)
            b.text(6, 300, 2, color, text)

    def _play_frame(self, b):
        b.fill_rect(0, 0, 480, 36, PANEL)
        b.draw_rect(8, 40, 464, 8, GREY)
        b.draw_rect(8, 56, 168, 236, WHITE)
        for cx, name in zip(BOTTLE_X, g.BOTTLES):
            bottle(b, cx, DRINK[name], name)
            b.text(cx - len(name) * 3, 162, 1, GREY, name)
        b.text(324, 190, 2, WHITE, "POUR")
        for (start, end, color), label in zip(GAUGE_ZONES, ("STOP", "POUR", "SPLASH")):
            b.fill_rect(start, GAUGE_Y, end - start, GAUGE_H, color)
            b.text(min(centered(label, 1, start, end - start), 480 - text_width(label, 1)),
                   GAUGE_LABEL_Y, 1, color, label)
        b.text(324, 274, 1, WHITE, "A = SERVE   B = DUMP")

    def _pause_box(self, b, reason):
        b.fill_rect(80, 100, 320, 120, PANEL)
        b.draw_rect(80, 100, 320, 120, RED, 2)
        b.text(centered("PAUSED", 3), 116, 3, RED, "PAUSED")
        line = reason or "TAKE A BREAK"
        b.text(centered(line, 2), 152, 2, WHITE, line)
        if reason:
            hint = "RECONNECT IT OR RESTART THE APP"
            b.text(centered(hint, 1), 180, 1, GREY, hint)
        hint = "STICK: RESUME     B: MENU"
        b.text(centered(hint, 2), 196, 2, AMBER, hint)

    def _top_bar(self, b, game):
        if self._changed("guest", (game.guest, game.guests, game.tutorial)):
            b.fill_rect(8, 10, 132, 16, PANEL)
            label = "TRAINING" if game.tutorial else f"GUEST {game.guest + 1}/{game.guests}"
            b.text(8, 10, 2, WHITE, label)
        if self._changed("lives", game.lives):
            for i, x in enumerate(LIVES_X):
                b.fill_circle(x, 18, 7, PANEL)
                if i < game.lives:
                    b.fill_circle(x, 18, 6, RED)
                else:
                    b.draw_circle(x, 18, 6, GREY)
        if self._changed("score", game.score):
            text = f"SCORE {game.score}"
            b.fill_rect(280, 10, 192, 16, PANEL)
            b.text(472 - text_width(text, 2), 10, 2, YELLOW, text)

    def _timer(self, b, game):
        fraction = game.time_left / game.time_limit if game.time_limit else 0.0
        width = round(TIMER_W * max(0.0, min(1.0, fraction)))
        color = RED if fraction < 0.25 else AMBER
        old = self.cache.get("timer")
        if old == (width, color):
            return
        if old is None or old[1] != color or width > old[0]:
            b.fill_rect(TIMER_X, TIMER_Y, width, TIMER_H, color)
            b.fill_rect(TIMER_X + width, TIMER_Y, TIMER_W - width, TIMER_H, BLACK)
        else:
            b.fill_rect(TIMER_X + width, TIMER_Y, old[0] - width, TIMER_H, BLACK)
        self.cache["timer"] = (width, color)

    def _card(self, b, game):
        if self._changed("card", (game.guest, game.recipe_name, game.blind, game.tutorial)):
            b.fill_rect(9, 57, 166, 234, BLACK)
            b.text(16, 64, 2, WHITE, game.recipe_name)
            b.text(16, 86, 1, GREY, "FILL EACH LAYER")
            for i, (color, amount) in enumerate(game.recipe):
                y = ROW_Y + i * ROW_GAP
                b.fill_rect(18, y, 20, 20, DRINK[color])
                b.text(46, y + 2, 2, WHITE, f"{color} {amount}%")
            if game.tutorial:
                tips = tuple((tip, AMBER) for tip in TUTORIAL_TIPS)
            elif game.blind:
                tips = (("BLIND POUR: THE LINE", AMBER), ("HIDES AFTER 3 SECONDS", AMBER),
                        (POUR_TIPS[2], GREY))
            else:
                tips = tuple((tip, GREY) for tip in POUR_TIPS)
            for i, (tip, color) in enumerate(tips):
                b.text(16, 222 + i * 14, 1, color, tip)
            for key in ("row", "marks", "clock"):
                self.cache.pop(key, None)
        current = game.current_layer()
        old = self.cache.get("row")
        if self._changed("row", current):
            if old is not None:
                b.draw_rect(12, ROW_Y + old * ROW_GAP - 6, 160, 32, BLACK, 2)
            b.draw_rect(12, ROW_Y + current * ROW_GAP - 6, 160, 32, YELLOW, 2)
        marks = game.row_marks()
        old_marks = self.cache.get("marks") or ("",) * len(marks)
        if self._changed("marks", marks):
            for i, (mark, before) in enumerate(zip(marks, old_marks)):
                if mark == before:
                    continue
                y = ROW_Y + i * ROW_GAP + 2
                b.fill_rect(146, y, 24, 16, BLACK)
                if mark:
                    b.text(146, y, 2, {"OK": GREEN, "~": AMBER}.get(mark, RED), mark)
        seconds = math.ceil(game.time_left) if game.timed else None
        hurry = game.timed and game.time_left < game.time_limit * 0.25
        if self._changed("clock", (seconds, hurry)):
            b.fill_rect(16, 270, 156, 16, BLACK)
            text = f"TIME {seconds}s" if game.timed else "NO TIMER"
            b.text(16, 270, 2, RED if hurry else AMBER, text)

    def _bottles(self, b, game):
        old = self.cache.get("bottle")
        if not self._changed("bottle", game.selected):
            return
        for i, (cx, name) in enumerate(zip(BOTTLE_X, g.BOTTLES)):
            if i != game.selected and i != old:
                continue
            chosen = i == game.selected
            b.draw_rect(cx - 22, 66, 44, 112, YELLOW if chosen else BLACK, 2)
            b.fill_rect(cx - 15, 162, 30, 8, BLACK)
            b.text(cx - len(name) * 3, 162, 1, WHITE if chosen else GREY, name)

    # --- glass ----------------------------------------------------------------

    def _banner_text(self, game):
        if game.state == g.INTRO:
            first = "TRAINING" if game.tutorial else f"GUEST {game.guest + 1}/{game.guests}"
            return (first, WHITE, "HOLD STILL", GREEN)
        if game.state == g.SERVED:
            text = game.result_text
            if text == "TRY AGAIN":
                return (text, AMBER, "NO PROBLEM", WHITE)
            color = GREEN if text in ("PERFECT!", "GOOD!") else (AMBER if text == "OK!" else RED)
            if not game.result_points:
                return (text, color, "-1 LIFE", RED)
            points = f"+{game.result_points}"
            if game.multiplier > 1:
                points += f" X{game.multiplier}"  # back-to-back PERFECT combo
            return (text, color, points, YELLOW)
        return None

    def _line_ys(self, game):
        if not game.line_visible():
            return (None, None)
        current = game.current_layer()
        upcoming = current + 1 < len(game.recipe)
        return (level_y(game.target(current)),
                level_y(game.target(current + 1)) if upcoming else None)

    def _draw_lines(self, b, lines, arrows):
        current, upcoming = lines
        if upcoming is not None:
            b.fill_rect(IN_X, upcoming, IN_W, 1, GREY)
        if current is not None:
            b.fill_rect(IN_X, current - 1, IN_W, 2, YELLOW)
            if arrows:
                b.fill_triangle(200, current - 5, 209, current, 200, current + 5, YELLOW)
                b.fill_triangle(307, current - 5, 298, current, 307, current + 5, YELLOW)

    def _glass_full(self, b, game):
        b.fill_rect(*GLASS_AREA, BLACK)
        b.draw_rect(*GLASS_RECT, WHITE, 2)
        rows = row_colors(game.layers())
        paint_rows(b, rows, [i for i, color in enumerate(rows) if color != BLACK])
        lines = self._line_ys(game)
        self._draw_lines(b, lines, True)
        self.cache.update(rows=rows, lines=lines, banner=None)

    def _glass(self, b, game):
        banner = self._banner_text(game)
        new_guest = self._changed("glass_guest", (game.guest, game.recipe_name))
        if new_guest or (banner is None and self.cache.get("banner") is not None):
            self._glass_full(b, game)
        if banner is not None:
            if self._changed("banner", banner):
                x, y, w, h = BANNER
                b.fill_rect(x, y, w, h, PANEL)
                b.draw_rect(x, y, w, h, YELLOW, 2)
                b.text(centered(banner[0], 2, x, w), y + 14, 2, banner[1], banner[0])
                b.text(centered(banner[2], 2, x, w), y + 44, 2, banner[3], banner[2])
            return  # the banner covers the glass until it goes away

        rows = row_colors(game.layers())
        old_rows = self.cache["rows"]
        changed = [i for i in range(IN_H) if rows[i] != old_rows[i]]
        paint_rows(b, rows, changed)
        self.cache["rows"] = rows

        lines, old_lines = self._line_ys(game), self.cache["lines"]
        if lines != old_lines:
            current, upcoming = old_lines
            erase = []
            if current is not None:
                erase += [current - 1 - IN_TOP, current - IN_TOP]
                b.fill_rect(199, current - 6, 12, 13, BLACK)
                b.fill_rect(297, current - 6, 12, 13, BLACK)
            if upcoming is not None:
                erase.append(upcoming - IN_TOP)
            paint_rows(b, rows, [i for i in erase if 0 <= i < IN_H])
            self._draw_lines(b, lines, True)
            self.cache["lines"] = lines
        elif changed:
            # Liquid painted over a line; put it back (the arrows sit outside the glass).
            covered = set(changed)
            current, upcoming = lines
            touched = ((current is not None and {current - 1 - IN_TOP, current - IN_TOP} & covered)
                       or (upcoming is not None and upcoming - IN_TOP in covered))
            if touched:
                self._draw_lines(b, lines, False)

    def _needle(self, b, angle, active):
        x = needle_x(angle)
        old = self.cache.get("needle")
        if old == (x, active):
            return
        if old is not None:
            left = old[0] - NEEDLE_W // 2
            b.fill_rect(left, NEEDLE_TOP, NEEDLE_W, GAUGE_Y - NEEDLE_TOP, BLACK)
            bottom = GAUGE_Y + GAUGE_H
            b.fill_rect(left, bottom, NEEDLE_W, NEEDLE_TOP + NEEDLE_H - bottom, BLACK)
            for start, end, color in GAUGE_ZONES:
                lo, hi = max(start, left), min(end, left + NEEDLE_W)
                if lo < hi:
                    b.fill_rect(lo, GAUGE_Y, hi - lo, GAUGE_H, color)
        b.fill_rect(x - NEEDLE_W // 2, NEEDLE_TOP, NEEDLE_W, NEEDLE_H, WHITE if active else GREY)
        self.cache["needle"] = (x, active)
