"""Validated, calibrated controls for Bar Master.

DEAD_ZONE and INVERT_X match arcade/python/preview.py; keep them in sync with your
console's calibration.
"""
import json
import math

DEAD_ZONE = 26
INVERT_X = False

# Hold C while tilting to pour; letting go stops at once. Set False to pour by
# tilt alone (harder: stopping means returning to the neutral pose).
HOLD_TO_POUR = True
# Pouring follows how far the console tips away from the pose held while the
# guest is announced, so any comfortable holding angle works and no fixed
# Movement baseline is needed.
POUR_START_DEG = 10.0
POUR_FULL_DEG = 40.0
# Only one side pours. The game learns which side from the first deliberate pour
# (players are told to tilt left, toward the glass), so the Movement module can be
# mounted either way; tilting the other way then counts as "bottle up".
LEARN_DEG = 15.0
SPLASH_DEG = 55.0
SPLASH_REARM_DEG = 45.0
TILT_SMOOTHING = 0.35  # 0..1; higher follows the sensor faster but shakes more

BUTTONS, JOYSTICK, MOVEMENT = 1, 2, 4
ALL_MODULES = BUTTONS | JOYSTICK | MOVEMENT
A, B, C, STICK = 1, 2, 4, 8
STEP_THRESHOLD = 64  # stick travel that selects the next bottle
STEP_REARM = 32      # the stick must come back this close to center first

LIMITS = {
    "epoch": (0, 2**31 - 1), "connected": (0, 7), "buttons": (0, 15),
    "x": (-127, 128), "y": (-127, 128),
    "ax": (-16000, 16000), "ay": (-16000, 16000), "az": (-16000, 16000),
}


def parse_inputs(reply):
    """Decode the sketch's JSON snapshot; raise ValueError on anything unexpected."""
    data = json.loads(reply)
    if not isinstance(data, dict):
        raise ValueError("Input snapshot is not an object")
    for key, (low, high) in LIMITS.items():
        value = data.get(key)
        if type(value) is not int or not low <= value <= high:
            raise ValueError(f"Invalid input field: {key}")
    return data


def missing_names(missing):
    names = [name for bit, name in ((MOVEMENT, "MOVEMENT"), (JOYSTICK, "JOYSTICK"),
                                    (BUTTONS, "BUTTONS")) if missing & bit]
    return names


class Controls:
    """Button edges, a one-step-per-push bottle selector and the module status."""

    def __init__(self):
        self.connected = 0
        self.held = 0
        self.pressed = 0
        self.x = 0
        self.step = 0
        self._step_armed = True

    def update(self, data):
        self.connected = data["connected"]
        usable = (7 if self.connected & BUTTONS else 0) | (STICK if self.connected & JOYSTICK else 0)
        held = data["buttons"] & usable
        # Only a new press counts, so holding a button never repeats an action.
        self.pressed = held & ~self.held
        self.held = held
        x = data["x"] if self.connected & JOYSTICK else 0
        x = 0 if abs(x) < DEAD_ZONE else x
        self.x = -x if INVERT_X else x
        self.step = 0
        if self._step_armed and abs(self.x) >= STEP_THRESHOLD:
            self.step = 1 if self.x > 0 else -1
            self._step_armed = False
        elif abs(self.x) < STEP_REARM:
            self._step_armed = True

    def missing(self):
        return ALL_MODULES & ~self.connected


class Tilt:
    """Angle between the console's current pose and a neutral pose."""

    def __init__(self):
        self.vector = None
        self.neutral = None
        self.direction = None  # unit vector of the pouring side, once learned
        self.ok = False
        self._sum = None

    def update(self, data, capturing):
        sample = (data["ax"], data["ay"], data["az"])
        # Without Movement, or while the console is in free fall, there is no gravity to follow.
        if not data["connected"] & MOVEMENT or math.hypot(*sample) < 300:
            self.ok = False
            return
        self.ok = True
        if self.vector is None:
            self.vector = sample
        else:
            self.vector = tuple(v + TILT_SMOOTHING * (s - v) for v, s in zip(self.vector, sample))
        if capturing:
            # Average the pose held while capturing; it becomes "not pouring".
            if self._sum is None:
                self._sum = [0.0, 0.0, 0.0, 0]
            for i in range(3):
                self._sum[i] += self.vector[i]
            self._sum[3] += 1
            self.neutral = tuple(total / self._sum[3] for total in self._sum[:3])
        else:
            self._sum = None
        if self.neutral is None:
            self.neutral = self.vector

    def angle(self):
        """Tilt away from the neutral pose in any direction, in degrees."""
        if not self.ok or self.vector is None or self.neutral is None:
            return 0.0
        a, b = self.vector, self.neutral
        dot = a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
        cross = math.sqrt((a[1] * b[2] - a[2] * b[1]) ** 2 + (a[2] * b[0] - a[0] * b[2]) ** 2
                          + (a[0] * b[1] - a[1] * b[0]) ** 2)
        return math.degrees(math.atan2(cross, dot))

    def _sideways(self, vector):
        """Part of a vector across the neutral gravity direction."""
        n = _unit(self.neutral)
        along = sum(v * k for v, k in zip(vector, n))
        return tuple(v - along * k for v, k in zip(vector, n))

    def learn(self):
        """Remember the current tilt as the pouring side."""
        if self.ok and self.vector is not None and self.neutral is not None:
            side = self._sideways(_unit(self.vector))
            if math.hypot(*side) > 0.1:
                self.direction = _unit(side)

    def pour_angle(self):
        """Tilt toward the pouring side in degrees; the other side reads as zero or less."""
        if self.direction is None:
            return self.angle()  # not learned yet: the first pour may go either way
        if not self.ok or self.vector is None or self.neutral is None:
            return 0.0
        side = self._sideways(self.direction)
        size = math.hypot(*side)
        if size < 1e-6:
            return self.angle()
        toward = sum(t * s for t, s in zip(self._sideways(_unit(self.vector)), side)) / size
        return math.degrees(math.asin(max(-1.0, min(1.0, toward))))


def _unit(vector):
    size = math.sqrt(sum(v * v for v in vector)) or 1.0
    return tuple(v / size for v in vector)
