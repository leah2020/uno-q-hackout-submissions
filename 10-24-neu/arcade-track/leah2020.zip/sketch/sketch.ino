#include <Arduino.h>
#include <Arduino_RouterBridge.h>
#include <Arduino_Modulino.h>
#include <DIYables_TFT_Touch_Shield.h>
#include <math.h>
#include "draw_protocol.h"

#if !defined(ARDUINO_UNO_Q)
#error "Select Arduino UNO Q for this sketch."
#endif

// Hosts select the controller fitted to their preassembled consoles.
#ifndef ARCADE_TFT_HX8357D
#define ARCADE_TFT_HX8357D 1
#endif
#if ARCADE_TFT_HX8357D
DIYables_TFT_HX8357D_Shield display;
#else
DIYables_TFT_RM68140_Shield display;
#endif

const uint8_t BUTTONS_ADDRESS = 0x3E;
const uint8_t JOYSTICK_ADDRESS = 0x2C;
ModulinoButtons buttons(BUTTONS_ADDRESS);
ModulinoMovement movement;
bool movementReady = false;

const uint16_t TFT_BLACK = 0x0000;
const uint16_t TFT_WHITE = 0xFFFF;
const uint16_t TFT_PINK = 0xF8F8;
const unsigned long FRAME_TIMEOUT_MS = 1500;
unsigned long lastFrameAt = 0;
bool waiting = true;
// Changes whenever the sketch repaints the screen on its own, telling Python to redraw.
int screenEpoch = 0;
int ledMask = -1;

bool readPacket(uint8_t address, uint8_t payload[3]) {
  // update() means "changed", not "read succeeded"; reject incomplete wire packets.
  int count = Wire1.requestFrom(address, (uint8_t)4);
  if (count != 4) {
    while (Wire1.available()) Wire1.read();
    return false;
  }
  Wire1.read();  // Modulino pinstrap address precedes the three input bytes.
  for (int i = 0; i < 3; ++i) payload[i] = Wire1.read();
  return true;
}

String readInputs() {
  uint8_t buttonData[3] = {};
  uint8_t stickData[3] = {};
  bool buttonsOk = readPacket(BUTTONS_ADDRESS, buttonData);
  bool joystickOk = readPacket(JOYSTICK_ADDRESS, stickData);
  bool movementOk = movementReady && movement.update();
  float ax = movementOk ? movement.getX() : 0;
  float ay = movementOk ? movement.getY() : 0;
  float az = movementOk ? movement.getZ() : 0;
  movementOk = movementOk && isfinite(ax) && isfinite(ay) && isfinite(az);
  int connected = (buttonsOk ? 1 : 0) | (joystickOk ? 2 : 0) | (movementOk ? 4 : 0);
  int pressed = 0;
  if (buttonsOk) {
    for (int i = 0; i < 3; ++i) if (buttonData[i]) pressed |= 1 << i;
  }
  if (joystickOk && stickData[2]) pressed |= 8;
  char json[200];
  snprintf(json, sizeof(json),
           "{\"epoch\":%d,\"connected\":%d,\"buttons\":%d,\"x\":%d,\"y\":%d,"
           "\"ax\":%d,\"ay\":%d,\"az\":%d}",
           screenEpoch, connected, pressed,
           joystickOk ? 128 - (int)stickData[0] : 0,
           joystickOk ? 128 - (int)stickData[1] : 0,
           movementOk ? (int)(constrain(ax, -16.0f, 16.0f) * 1000) : 0,
           movementOk ? (int)(constrain(ay, -16.0f, 16.0f) * 1000) : 0,
           movementOk ? (int)(constrain(az, -16.0f, 16.0f) * 1000) : 0);
  return String(json);
}

// The game owns the button LEDs; only write them when they change.
void setLeds(uint8_t mask) {
  if (mask == ledMask) return;
  ledMask = mask;
  buttons.setLeds((mask & 1) != 0, (mask & 2) != 0, (mask & 4) != 0);
}

void showWaiting() {
  display.fillScreen(TFT_BLACK);
  display.setTextSize(4);
  display.setTextColor(TFT_PINK);
  display.setCursor(120, 120);
  display.print("BAR MASTER");
  display.setTextSize(2);
  display.setTextColor(TFT_WHITE);
  display.setCursor(108, 176);
  display.print("Waiting for App Lab...");
  setLeds(0);
  screenEpoch = screenEpoch == 2147483647 ? 1 : screenEpoch + 1;
  waiting = true;
}

// Draw one batch from Python, then reply with fresh controls (one round trip per frame).
String barDraw(MsgPack::bin_t<uint8_t> data) {
  if (!BarDraw::run(display, setLeds, data.data(), data.size())) return String("");
  lastFrameAt = millis();
  waiting = false;
  return readInputs();
}

void setup() {
  Serial.begin(115200);
  // Register RPC methods first so a slow or missing peripheral can't hide them from Python.
  bool bridgeOk = Bridge.begin();
  if (bridgeOk) {
    Bridge.provide_safe("bar_draw", barDraw);
    Bridge.provide_safe("arcade_read_inputs", readInputs);
  }
  Serial.println(bridgeOk ? "Bridge ready" : "Bridge failed");
  Modulino.begin(Wire1);
  buttons.begin();
  movementReady = movement.begin();
  Serial.println("Modulino init done");
  display.begin();
  display.setRotation(1);  // Landscape: 480 x 320.
  display.setTextWrap(false);
  showWaiting();
  if (!bridgeOk) {
    display.setTextColor(TFT_WHITE, TFT_BLACK);
    display.setCursor(84, 220);
    display.print("Bridge failed: restart app");
  }
  Serial.println("Display init done");
}

void loop() {
  if (!waiting && millis() - lastFrameAt > FRAME_TIMEOUT_MS) showWaiting();
  delay(5);
}
