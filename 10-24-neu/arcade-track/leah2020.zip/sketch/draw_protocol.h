#pragma once

#include <stddef.h>
#include <stdint.h>

// Compact drawing commands sent by python/draw.py. One RPC carries a batch of
// commands so a frame costs one Bridge round trip instead of one per shape.
namespace BarDraw {
constexpr size_t MAX_PAYLOAD = 200;
constexpr size_t MAX_TEXT = 40;

enum Op : uint8_t {
  CLEAR = 1,
  FILL_RECT = 2,
  DRAW_RECT = 3,
  FILL_CIRCLE = 4,
  DRAW_CIRCLE = 5,
  LINE = 6,
  FILL_TRIANGLE = 7,
  TEXT = 8,
  LEDS = 9,
};

// Bytes before any variable data, including the opcode.
inline size_t headerSize(uint8_t op) {
  switch (op) {
    case CLEAR: return 3;
    case FILL_RECT: case DRAW_RECT: case LINE: return 11;
    case FILL_CIRCLE: case DRAW_CIRCLE: return 9;
    case FILL_TRIANGLE: return 15;
    case TEXT: return 11;
    case LEDS: return 2;
    default: return 0;
  }
}

inline int16_t readI16(const uint8_t* p) { return (int16_t)(uint16_t)(p[0] | (p[1] << 8)); }
inline uint16_t readU16(const uint8_t* p) { return (uint16_t)(p[0] | (p[1] << 8)); }

// Keep coordinates in a range the graphics library's integer math handles safely;
// the display driver clips anything outside the screen.
inline int16_t coord(const uint8_t* p) {
  int16_t v = readI16(p);
  return v < -1000 ? -1000 : (v > 2000 ? 2000 : v);
}

inline size_t opSize(const uint8_t* data, size_t at, size_t size) {
  size_t need = headerSize(data[at]);
  if (need == 0 || at + need > size) return 0;
  if (data[at] == TEXT) {
    size_t len = data[at + need - 1];
    if (len > MAX_TEXT || at + need + len > size) return 0;
    need += len;
  }
  return need;
}

// Check the whole batch before drawing so a damaged packet draws nothing.
inline bool validate(const uint8_t* data, size_t size) {
  if (size > MAX_PAYLOAD) return false;
  for (size_t at = 0; at < size;) {
    size_t need = opSize(data, at, size);
    if (need == 0) return false;
    at += need;
  }
  return true;
}

template <typename Display, typename Leds>
bool run(Display& display, Leds&& setLeds, const uint8_t* data, size_t size) {
  if (!validate(data, size)) return false;
  for (size_t at = 0; at < size;) {
    const uint8_t* p = data + at + 1;
    switch (data[at]) {
      case CLEAR:
        display.fillScreen(readU16(p));
        break;
      case FILL_RECT:
        display.fillRect(coord(p), coord(p + 2), coord(p + 4), coord(p + 6), readU16(p + 8));
        break;
      case DRAW_RECT:
        display.drawRect(coord(p), coord(p + 2), coord(p + 4), coord(p + 6), readU16(p + 8));
        break;
      case FILL_CIRCLE:
      case DRAW_CIRCLE: {
        int16_t r = coord(p + 4);
        r = r < 0 ? 0 : (r > 240 ? 240 : r);
        if (data[at] == FILL_CIRCLE) display.fillCircle(coord(p), coord(p + 2), r, readU16(p + 6));
        else display.drawCircle(coord(p), coord(p + 2), r, readU16(p + 6));
        break;
      }
      case LINE:
        display.drawLine(coord(p), coord(p + 2), coord(p + 4), coord(p + 6), readU16(p + 8));
        break;
      case FILL_TRIANGLE:
        display.fillTriangle(coord(p), coord(p + 2), coord(p + 4), coord(p + 6), coord(p + 8),
                             coord(p + 10), readU16(p + 12));
        break;
      case TEXT: {
        uint8_t size = p[4] < 1 ? 1 : (p[4] > 5 ? 5 : p[4]);
        uint16_t fg = readU16(p + 5);
        uint16_t bg = readU16(p + 7);
        uint8_t len = p[9];
        char text[MAX_TEXT + 1];
        for (uint8_t i = 0; i < len; ++i) {
          uint8_t c = p[10 + i];
          text[i] = (c >= 32 && c < 127) ? (char)c : '?';
        }
        text[len] = '\0';
        display.setTextSize(size);
        // Equal colors mean "no background", which draws only the letter pixels.
        if (fg == bg) display.setTextColor(fg);
        else display.setTextColor(fg, bg);
        display.setCursor(coord(p), coord(p + 2));
        display.print(text);
        break;
      }
      case LEDS:
        setLeds(p[0] & 7);
        break;
    }
    at += opSize(data, at, size);
  }
  return true;
}
}  // namespace BarDraw
